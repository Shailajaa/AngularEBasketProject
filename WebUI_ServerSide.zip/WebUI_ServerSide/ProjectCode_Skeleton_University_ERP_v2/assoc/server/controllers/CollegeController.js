/*
// Created by Academy on 20/10/16
// Controller for Managing Colleges
*/
var HttpStatus = require('http-status');
var College = require('../models/College');

//Export the save method to save a College
//Check if the College already exists
//throw a College already exists error
//If not then create the College
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    //Write your save code here
};

//Export the list method to return a list of all Colleges
exports.list = function(req, res){
    //Write your list code here
};

//Export the activeList method to return a list of all Active Colleges
exports.activeList = function(req, res){
    //Write your activeList code here
};

//Export the getByCountry method to list 
//all active Colleges for a given Country
//The Country id is passed as id in the request parameters
exports.getByCountry = function(req, res){
    //Write your getByCountry code here
};

//Export the get method to return
//a College object given the id in the request parameters
exports.get = function(req, res){
    //Write your get code here
};

//Export the update method
//Find the College by id passed in the request parameters 
//and update it with the College object in the request body
//Throw an error
//If the College name already exists
//If the College is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    //Write your update code here
};

//Export the activate method
//Find the College by the id request parameter
//Update the College activeStatus to true
//Throw an error
//If the College is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    //Write your activate code here
};

//Export the deactivate method
//Find the College by the id request parameter
//Update the College activeStatus to false
//Throw an error
//If the College is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    //Write your deactivate code here
};
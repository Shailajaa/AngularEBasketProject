/*
// Created by Academy on 20/10/16
// Controller for Managing Hostels
*/

var HttpStatus = require('http-status');
var College = require('../models/College');
var Hostel = require('../models/Hostel');

var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;

//Export the save method to save a Hostel
//Check if the Hostel already exists for the given College
//throw a Hostel already exists error
//If not then create the Hostel for the Given College
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    //Write your save code here
};

//Export the list method to return a list of all Hostels
exports.list = function(req, res){
    //Write your list code here
};

//Export the getByCollege method to list 
//all Hostels for a given College
//The College id is passed as id in the request parameters
exports.getByCollege = function(req, res){
    //Write your getByCollege code here
};

//Export the activeListByCollege method to list 
//all active Hostels for a given College
//The College id is passed as id in the request parameters
exports.activeListByCollege = function(req, res){
    //Write your activeListByCollege code here
}

//Export the get method to return
//a Hostel object given the id in the request parameters
exports.get = function(req, res){
    //Write your get code here
};

//Export the update method
//Find the Hostel by id passed in the request parameters 
//and update it with the Hostel object in the request body
//Throw an error
//If the Hostel name already exists
//If the Hostel is not found
////Use the validationErrors service for any validation errors
exports.update = function(req, res){
    //Write your update code here
};

//Export the activate method
//Find the Hostel by the id request parameter
//Update the Hostel activeStatus to true
//Throw an error
//If the Hostel is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    //Write your activate code here
};

//Export the deactivate method
//Find the Hostel by the id request parameter
//Update the Hostel activeStatus to false
//Throw an error
//If the Hostel is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    //Write your deactivate code here
};
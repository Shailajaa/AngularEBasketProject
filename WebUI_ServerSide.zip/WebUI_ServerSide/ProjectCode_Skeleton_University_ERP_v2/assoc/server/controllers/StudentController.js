/*
// Created by Academy on 20/10/16
// Controller for Managing Students
*/
var Student = require('../models/Student');
var College = require('../models/College');
var Hostel = require('../models/Hostel');

var HttpStatus = require('http-status');
var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;

//Export the save method to save a Student
//Check if the Roll No already exists 
//throw a Roll no already exists error
//If not then create the Student
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    //Write your save code here
};

//Export the get method to return
//a Student object given the id in the request parameters
//If the student is not found
//Throw a student not found error
exports.get = function(req, res){
    //Write your get code here
};

//Export the list method to return a list of all Students
exports.list = function(req, res){
    //Write your list code here
};

//Export the getByCollege method to list 
//all active Students for a given College
//The College id is passed as id in the request parameters
exports.getByCollege = function(req,res){
    //Write your getByCollege code here
};

//Export the update method
//Find the Student by id passed in the request parameters 
//and update it with the Student object in the request body
//Throw an error
//If the Student Roll No already exists
//If the Roll No is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    //Write your update code here
};

//Export the activate method
//Find the Student by the id request parameter
//Update the Student activeStatus to true
//Throw an error
//If the Student is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    //Write your activate code here
};

//Export the deactivate method
//Find the Student by the id request parameter
//Update the Student activeStatus to false
//Throw an error
//If the Student is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    //Write your deactivate code here
};

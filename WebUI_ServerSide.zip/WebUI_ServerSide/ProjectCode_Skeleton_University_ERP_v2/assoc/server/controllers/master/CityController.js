/*
// Created by Academy on 20/10/16
// Controller for Managing City Master
*/

var HttpStatus = require('http-status');
var State = require('../../models/master/State');
var City = require('../../models/master/City');


//Export the save method to save a City
//Check if the city already exists 
//throw a city already exists error
//If not then create the city
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    //Write your save code here
};

//Export the list method to return a list of all Cities
exports.list = function(req, res){
    //Write your list code here
};


//Export the activeList method to list all active Cities
exports.activeList = function(req, res){
    //Write your activeList code here
};

//Export the getByState method to list 
//all active Cities for a given State
//The state id is passed as id in the request parameters
exports.getByState = function(req, res){
    //Write your code to get the list of Cities for a given state
}

//Export the get method to return
//a City object given the id in the request parameters
exports.get = function(req, res){
    //Write your code the  get a city for given an id
};

//Export the update method
//Find the city by id passed in the request parameters 
//and update it with the city object in the request body
//Throw an error
//If the city name already exists
//If the city is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    //Write your update code here
};

//Export the activate method
//Find the city by the id request parameter
//Update the city activeStatus to true
//Throw an error
//If the city is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    //Write your activate code here
};

//Export the deactivate method
//Find the city by the id request parameter
//Update the city activeStatus to false
//Throw an error
//If the city is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    //Write your deactivate code here
};
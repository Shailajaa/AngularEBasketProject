/*
// Created by Academy on 20/10/16
// Controller for Managing the Country Master
*/

var Country = require('../../models/master/Country');
var HttpStatus = require('http-status');

//Export the save method to save a Country
//Check if the country already exists 
//throw a country already exists error
//If not then create the country
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    //Write your save code here
};

//Export the list method to return a list of all Countries
exports.list = function(req, res){
    //Write your list code here
};

//Export the activeList method to list all active Countries
exports.activeList = function(req, res){
    //Write your activeList code here
};

//Export the update method
//Find the Country by id passed in the request parameters 
//and update it with the country object in the request body
//Throw an error
//If the country name already exists
//If the country is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    //Write your update code here
};

//Export the activate method
//Find the Country by the id in request parameter
//Update the Country's activeStatus to true
//Throw an error
//If the country is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    //Write your activate code here
};

//Export the deactivate method
//Find the Country by the id in request parameter
//Update the Country's activeStatus to false
//Throw an error
//If the country is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    //Write your deactivate code here
};
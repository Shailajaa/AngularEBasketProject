/*
// Created by Academy on 20/10/16
*/
var HttpStatus = require('http-status');

var StudentController = require('./controllers/StudentController');
var CountryController = require('./controllers/master/CountryController');
var StateController = require('./controllers/master/StateController');
var CityController = require('./controllers/master/CityController');
var CollegeController = require('./controllers/CollegeController');
var HostelController = require('./controllers/HostelController');

module.exports = function(router){

	router.all('/', function (req, res) {
		res.sendFile('index.html',{ root:'./public/'});
	});

    router.all('/isServerRunning', function(req,res) {
        res.status(200).json({code:200, data: "Server Running..."})
    });

    router.all('/getTime', function(req,res) {
        res.status(200).json({code:200, data: {date: new Date().toUTCString()}})
    });

    /*
        Add your routes here
     */

    // Student routes


    // Country routes


    // State routes


    // College routes

    
    // Hostel routes


    // City routes
    

};
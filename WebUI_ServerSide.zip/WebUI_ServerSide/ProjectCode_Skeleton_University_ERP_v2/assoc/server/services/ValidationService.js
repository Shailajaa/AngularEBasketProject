/*
// Created by Academy on 20/10/16
// Create ValidationService with a single function validationErrors
// Capture the mongodb errors and return them as Understandable messages
// For example if a required field is not included, then capture the error
// return <field name> is Required
*/
exports.validationErrors = function (err) {
    var errors = {};
    
    // Write your code here
    
    return errors;
};